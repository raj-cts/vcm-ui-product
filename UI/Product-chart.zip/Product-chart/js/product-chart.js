$(document).ready(function() {
    var selectedYear = 'monthly';
    var jsonData;
    $('input:radio[name="time"]').change(
        function() {
            if ($(this).is(':checked')) {
                selectedYear = $(this).val();
                $(".product-table").html('');
                filterData(jsonData);

            }
        });
    $.getJSON('product-chart.json', function(data) {
        jsonData = data;
        console.log(jsonData);
        filterData(data);

    });

    function filterData(data) {
        var selecedData = data.filter(element => {
            return element.timeFrame.type == selectedYear;
        });

        selecedData.forEach((element, index) => {
            var catg = element.xAxis.categories;
            var series = element.series;
            var row = $("<tr/>")

            row.append($("<th>" + '' + "</th>"));
            catg.forEach((item) => {
                row.append($("<th>" + item + "</th>"));
            });
            $(".product-table").append(row);
            series.forEach((item) => {
                var seriesRow = $("<tr />");
                seriesRow.append($("<td>" + item.initialName + "</td>"));

                item.data.forEach((dataItem) => {
                    seriesRow.append($("<td>" + dataItem + "</td>"));
                })
                $(".product-table").append(seriesRow);
            });

        });


    }
    var chartData = [{
        "classes": "N/A",
        "title": {
            "text": ""
        },
        "displayTable": true,
        "timeFrame": {
            "type": "monthly"
        },
        "chart": {
            "type": "column"
        },
        "xAxis": {
            "initialCategories": "",
            "categories": [
                "3 Mo",
                "YTD",
                "1 Yr",
                "3 Yr",
                "5 Yr",
                "Since Inception"
            ]
        },
        "yAxis": {
            "title": {
                "text": ""
            },
            "labels": {
                "formatter": ""
            }
        },
        "credits": {
            "enabled": false
        },
        "tooltip": {
            "valueSuffix": "%"
        },
        "series": [{
                "name": "",
                "initialName": "VictoryShares US 500 Volatility Wtd ETF",
                "data": [-7.930000000000, -9.930000000000,
                    2.950000000000,
                    7.420000000000,
                    7.740000000000,
                    8.240000000000
                ],
                "afterClassTxt": " @ NAV (%)",
                "dataOrderBy": 0
            },
            {
                "name": "",
                "initialName": "VictoryShares US 500 Volatility Wtd ETF",
                "data": [-7.850000000000, -9.780000000000,
                    3.090000000000,
                    7.450000000000,
                    7.700000000000,
                    8.260000000000
                ],
                "afterClassTxt": " @ Market Price (%)",
                "dataOrderBy": 0
            },
            {
                "name": "",
                "initialName": "Nasdaq Victory US Lg Cap 500 Vol Wtd Index",
                "data": [-7.870000000000, -9.900000000000,
                    3.310000000000,
                    7.800000000000,
                    8.130000000000,
                    null
                ],
                "afterClassTxt": "",
                "dataOrderBy": 0
            },
            {
                "name": "",
                "initialName": "S\u0026P 500® Index",
                "data": [-5.500000000000, -8.270000000000,
                    8.190000000000,
                    9.870000000000,
                    9.230000000000,
                    null
                ],
                "afterClassTxt": "",
                "dataOrderBy": 0
            }
        ],
        "asOf": "02/29/2020",
        "timeFrameAsOf": "02/29/2020",
        "link": "",
        "portfolioPercent": ""
    }, {
        "classes": "N/A",
        "title": {
            "text": ""
        },
        "displayTable": true,
        "timeFrame": {
            "type": "quarterly"
        },
        "chart": {
            "type": "column"
        },
        "xAxis": {
            "initialCategories": "",
            "categories": [
                "3 Mo",
                "YTD",
                "1 Yr",
                "3 Yr",
                "5 Yr",
                "Since Inception"
            ]
        },
        "yAxis": {
            "title": {
                "text": ""
            },
            "labels": {
                "formatter": ""
            }
        },
        "credits": {
            "enabled": false
        },
        "tooltip": {
            "valueSuffix": "%"
        },
        "series": [{
                "name": "",
                "initialName": "VictoryShares US 500 Volatility Wtd ETF",
                "data": [
                    7.190000000000,
                    30.320000000000,
                    30.320000000000,
                    13.380000000000,
                    10.660000000000,
                    10.570000000000
                ],
                "afterClassTxt": " @ NAV (%)",
                "dataOrderBy": 0
            },
            {
                "name": "",
                "initialName": "VictoryShares US 500 Volatility Wtd ETF",
                "data": [
                    7.160000000000,
                    30.320000000000,
                    30.320000000000,
                    13.380000000000,
                    10.660000000000,
                    10.560000000000
                ],
                "afterClassTxt": " @ Market Price (%)",
                "dataOrderBy": 0
            },
            {
                "name": "",
                "initialName": "Nasdaq Victory US Lg Cap 500 Vol Wtd Index",
                "data": [
                    7.290000000000,
                    30.820000000000,
                    30.820000000000,
                    13.780000000000,
                    11.080000000000,
                    null
                ],
                "afterClassTxt": "",
                "dataOrderBy": 0
            },
            {
                "name": "",
                "initialName": "S\u0026P 500® Index",
                "data": [
                    9.070000000000,
                    31.490000000000,
                    31.490000000000,
                    15.270000000000,
                    11.700000000000,
                    null
                ],
                "afterClassTxt": "",
                "dataOrderBy": 0
            }
        ],
        "asOf": "12/31/2019",
        "timeFrameAsOf": "12/31/2019",
        "link": "",
        "portfolioPercent": ""
    }]
    $('input:radio[name="chart"]').change(

        function() {
            //var data = chartData[0];
            // filterchart(data);
            if ($(this).is(':checked')) {
                var Selected = $(this).val();
                if (Selected == "monthly") {
                    data = chartData[0];
                    filterchart(data);
                } else if (Selected == "quarterly")
                    var data = chartData[1];
                filterchart(data);

            }
        });

    function filterchart(data) {
        Highcharts.chart('product-chart', data);
    }


});