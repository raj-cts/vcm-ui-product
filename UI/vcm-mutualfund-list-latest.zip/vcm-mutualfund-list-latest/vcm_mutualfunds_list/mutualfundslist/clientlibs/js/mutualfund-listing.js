$(document).ready(function () {
    // var fundstable;
    var responseData;
    var filterdata = [];
    var userType;
    var fixedleftColumns;
    var timer;
    var selectedFilters = [];

    // $.ajax({url: "js/mockdata.json",       
    //    success: function(response) { 
    //     responseData = response.data;
    //     if(responseData.length){
    //       createTable(responseData); 
    //     }                       
    //    },
    //    error: function (errorMessage) { 
    //      console.log(errorMessage); 
    //    }
    // });

    var ajaxData = $.parseJSON($.ajax({
      url:  'js/mockdata.json', //https://dev.api.vcm.com/funds/retailFunds
      dataType: "json", 
      async: false
    }).responseText);

   responseData = ajaxData.data;
   userType = ajaxData.user;
   console.log(userType);

    //console.log(responseData);
    createList(responseData);

    calculateWidth();

    //  function createTable(totalData){
         var fundstable = $('#fundslistTable').DataTable({
         data: responseData,
         deferRender: true,
         scrollX: true,
        //  scrollY: "300px",
         scrollCollapse: true,
         paging: false,
         autoWidth: false,
         fixedColumns: {
           leftColumns: fixedleftColumns,
           rightColumns: 0,
           heightMatch: "auto"
         },
         language: {
           "info": "Showing: _TOTAL_ of _MAX_ Funds",
           "infoFiltered": "",
           "infoEmpty": "Showing: _TOTAL_ of _MAX_ Funds"
         },
         columns :[
           { className: "ticker", "data": "ticker",
             "render": function ( data) {
                return `<span class="tickertext">${data}</span>`
              } 
           },
           { className: "fundname","data": "fund",
              "render": function ( data) { 
                return `<a href="">${data.fundname}</a><div class="">${data.class}</div>`
              } 
           },
           { className: "assetclass","data": "assetclass" },
           { className: "ytd","data": "ytd",
              "render": function ( data) { 
                return `<p><span class="ytdtext">${data.nav}</span><span class="ytdvalue">${data.ytdvalue}</span></p>
                        <p class="finance-user hidden"><span class="ytdtext">${data.load}</span><span class="ytdvalue">${data.loadvalue}</span></p>`
             } 
           },
           { className: "yearone","data": "performance",
              "render": function ( data) { 
                  return `<p><span class="performance-monthly-data">${data.monthly.yearone.nav}</span><span class="performance-quarterly-data hidden">${data.quarterly.yearone.nav}</span></p>
                   <p class="finance-user hidden"><span class="performance-monthly-data">${data.monthly.yearone.load}</span><span class="performance-quarterly-data hidden">${data.quarterly.yearone.load}</span></p>`
              } 
            },
           { className: "yearthree","data": "performance",
            "render": function ( data) { 
              return `<p><span class="performance-monthly-data">${data.monthly.yearthree.nav}</span><span class="performance-quarterly-data hidden">${data.quarterly.yearthree.nav}</span></p>
              <p class="finance-user hidden"><span class="performance-monthly-data">${data.monthly.yearthree.load}</span><span class="performance-quarterly-data hidden">${data.quarterly.yearthree.load}</span></p>`
            } 
          },
           { className: "yearfive","data": "performance",
            "render": function ( data) { 
              return `<p><span class="performance-monthly-data">${data.monthly.yearfive.nav}</span><span class="performance-quarterly-data hidden">${data.quarterly.yearfive.nav}</span></p>
              <p class="finance-user hidden"><span class="performance-monthly-data">${data.monthly.yearfive.load}</span><span class="performance-quarterly-data hidden">${data.quarterly.yearfive.load}</span></p>`
            } 
           },
           { className: "yearten","data": "performance",
            "render": function ( data) { 
              return `<p><span class="performance-monthly-data">${data.monthly.yearten.nav}</span><span class="performance-quarterly-data hidden">${data.quarterly.yearten.nav}</span></p>
              <p class="finance-user hidden"><span class="performance-monthly-data">${data.monthly.yearten.load}</span><span class="performance-quarterly-data hidden">${data.quarterly.yearten.load}</span></p>`
            }  
          },
           { className: "inception","data": "performance",
            "render": function ( data) { 
              return `<p><span class="performance-monthly-data">${data.monthly.since_inception.nav}</span><span class="performance-quarterly-data hidden">${data.quarterly.since_inception.nav}</span></p>
              <p class="finance-user hidden"><span class="performance-monthly-data">${data.monthly.since_inception.load}</span><span class="performance-quarterly-data hidden">${data.quarterly.since_inception.load}</span></p>`
            } 
          },
           { className: "inceptdate","data": "inceptdate" },
           { className: "gross","data": "gross" },
           { className: "net", "data": "net" },
           { className: "risk", "data": "risk",
            "render": function ( data) {
              var riskvalue = parseInt(data);
              var riskfieldTemplate = '';
              for(var i = 1;i<= 7; i++){
                if(i <= riskvalue){
                  riskfieldTemplate = riskfieldTemplate + ' <span class="risk-field active"></span>'
                }else{
                  riskfieldTemplate = riskfieldTemplate + '<span class="risk-field"></span>'
                }
              }
              return `<p class="fund-content-header">${riskfieldTemplate}</p>`  
            } },
           { className: "ratingoverall","data": "rating.overall",
            "render": function ( data) { 
              var ratingvalue = parseInt(data.value);
              var stariconTemplate = '';
              for(var i = 1;i<= 5; i++){
                if(i <= ratingvalue){
                  stariconTemplate = stariconTemplate + '<i class="fa fa-star fa-lg active"></i>'
                }else{
                  stariconTemplate = stariconTemplate + '<i class="fa fa-star fa-lg"></i>'
                }
              }
              return `<div class="overall-rating"><span>${stariconTemplate}</span></div>
                      <div class="rating-total">Out of ${data.total} funds</div>`
              } 
            },
           { className: "ratingyearthree","data": "rating.yearthree",
            "render": function ( data) { 
              return `<div>${data.value}<span class="rating-star-icon"></span></div><div class="rating-total">Out of ${data.total} funds</div>`
            } 
          },
           { className: "ratingyearfive","data": "rating.yearfive",
            "render": function ( data) { 
              return `<div>${data.value}<span class="rating-star-icon"></span></div><div class="rating-total">Out of ${data.total} funds</div>`
            }
          },
           { className: "ratingyearten","data": "rating.yearten",
            "render": function ( data) { 
              return `<div>${data.value}<span class="rating-star-icon"></span></div><div class="rating-total">Out of ${data.total} funds</div>`
            } 
          },
           { className: "ratingcategory", "data": "rating.category"},
           { className: "ratingfundsheet", "data": "rating.sheet"}
         ],            
         columnDefs: [
           { "orderable": false, "targets": [ 2, 3, 9, 10, 11, 17, 18] },
           { "searchable": false, "targets": [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18] },
           { "visible": false, "targets": [13, 14, 15, 16, 17, 18] }
         ],
         initComplete: function (settings, json) {
           // if user is not normal user showing double row
            if(userType.toLowerCase() === "financer"){
              $('.finance-user').removeClass('hidden');
            }
            // var reqHeight = $('.dataTables_scrollBody').height();
            // $('.DTFC_LeftBodyWrapper').css("height", reqHeight);
          $(".dataTables_scrollBody").addClass("dragscroll");
          var win = $(this); //this = window
          if ($(window).width() < 768) {
            $(".dragscroll").css("overflow","scroll");
          }else{
            $(".dragscroll").css("overflow","hidden");
          }
          //$(".dragscroll").css("overflow","hidden");
           $(".fundscount").html($(".dataTables_info").text());  
           loadScript('js/dragscroll.js');     
         }
   
       });
      // };

      $(".nav-link").on("click", function(){
        if($(this).text().toLowerCase() == "performance") {
          fundstable.columns([ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]).visible(true);
          fundstable.columns([13, 14, 15, 16, 17, 18]).visible(false).draw();
          $('.performance-scrollablesection').removeClass('hidden');
          $('.rating-scrollablesection').addClass('hidden');
          $('.current').removeClass('current');
          $(this).parent().addClass('current');
          checkselectedView();
        }else{
          fundstable.columns([0, 1, 2, 13, 14, 15, 16, 17, 18]).visible(true);
          fundstable.columns([3, 4, 5, 6, 7, 8, 9, 10, 11, 12]).visible(false).draw();
          $('.performance-scrollablesection').addClass('hidden');
          $('.rating-scrollablesection').removeClass('hidden');
          $('.current').removeClass('current');
          $(this).parent().addClass('current');
          checkselectedView();
        }
      })

      function checkselectedView(){
        if($('.list-icon').hasClass('active')){
          $('.performance-content-list-view').removeClass('hidden');
          $('.performance-content-grid-view').addClass('hidden');
          $('.rating-content-grid-view').addClass('hidden'); 
        }else{
          var selectedTab = $('.nav-link.active').text().toLowerCase();
        if(selectedTab == "performance"){
          $('.performance-content-list-view').addClass('hidden');
          $('.performance-content-grid-view').addClass('hidden');
          $('.rating-content-grid-view').removeClass('hidden');
        }else{
          $('.performance-content-list-view').addClass('hidden');
          $('.performance-content-grid-view').removeClass('hidden');
          $('.rating-content-grid-view').addClass('hidden');
        }
        }
      }


      $(".toggle-icon").click(function(){
        if($(this).hasClass('list-icon')) {
          $('.grid-icon').removeClass("active");
          $('.list-icon').addClass("active");
          displayListView();
        }else{
          $('.grid-icon').addClass("active");
          $('.list-icon').removeClass("active");
          displayGridView();
        }
      });

      function displayListView(){
        $('.performance-content-list-view').removeClass('hidden');
        $('.performance-content-grid-view').addClass('hidden');
        $('.rating-content-grid-view').addClass('hidden');        
      }
      function displayGridView(){

        var selectedTab = $('.nav-link.active').text().toLowerCase();
        if(selectedTab == "performance"){
          $('.performance-content-list-view').addClass('hidden');
          $('.performance-content-grid-view').removeClass('hidden');
          $('.rating-content-grid-view').addClass('hidden');
        }else{
          $('.performance-content-list-view').addClass('hidden');
          $('.performance-content-grid-view').addClass('hidden');
          $('.rating-content-grid-view').removeClass('hidden');
        }
      }

  function calculateWidth() {
    var win = $(this); //this = window
    if (win.width() < 768) {
      fixedleftColumns = 1;
      // redrawTable(responseData);
      $('#monthend-mobile').prop('checked', 'true');
      $('.sticky-footer').removeClass('hidden');
      $('.content').addClass('mobile-content-width').removeClass('pc-content-width');
      $('.sidebar-collapse').addClass('hidden').removeClass('filter-width');
      $('.mobile-radiobuttons-section').removeClass('hidden');
      $('.pc-radiobuttons-section').addClass('hidden');
      $('.sidebar-collapse .accordion, .sticky-footer .accordion').remove();
      $('.sticky-footer .panel').append(filterTemplate);
      console.log(win.width() + "Mobile");
    }
    else {
      fixedleftColumns = 3;
      // redrawTable(responseData);
      $(".funds-list").addClass("active");
      $('.sticky-footer').addClass('hidden');
      $('.content').removeClass('mobile-content-width').addClass('pc-content-width');
      $('.sidebar-collapse').removeClass('hidden').addClass('filter-width');
      $('.mobile-radiobuttons-section').addClass('hidden');
      $('.pc-radiobuttons-section').removeClass('hidden');
      $('.sticky-footer .accordion, .sidebar-collapse .accordion').remove();
      $('.sidebar-collapse').append(filterTemplate);      
      console.log(win.width() + "PC");
    }
    filterChange();
    selectCheckboxes();   
    return fixedleftColumns; 
    //console.log(fundstable);
    // createTable(responseData);
  }

function selectCheckboxes(){
    if(selectedFilters.length > 0){
        selectedFilters.forEach((filter) => {
          $('.accordion input[type="checkbox"]').each(function(){        
              if(filter == this.id){
                $(this).prop("checked", true);
              }
            });
        })
     }
};


  $(window).on('resize', function(){
    var aa = calculateWidth();
    console.log(aa);
    // fundstable.fixedColumns({leftColumns: aa}).update();     
    //  redrawTable(responseData);
    // $(".fundscount").html($(".dataTables_info").text()); 
  });

  
  // Search mutual funds
  $('#searchFunds').on('keyup change', function () {
    const searchKey = this.value;
    var searchResult = [];
    if ($('.content').hasClass('mobile-content-width')) {
      if (filterdata.length) {
        searchResult = filterdata.filter(item => {
          return (item.ticker).toLowerCase().indexOf(searchKey.toLowerCase()) > -1 || (item.fund.fundname).toLowerCase().indexOf(searchKey.toLowerCase()) > -1
        })
        createList(searchResult);      
      } else {
        searchResult = responseData.filter(item => {
          return (item.ticker).toLowerCase().indexOf(searchKey.toLowerCase()) > -1 || (item.fund.fundname).toLowerCase().indexOf(searchKey.toLowerCase()) > -1
        })
        createList(searchResult);
      }
    }
    fundstable.search(searchKey).draw();
    $(".fundscount").html($(".dataTables_info").text());
  });



// filter checkboxes
function filterChange(){
    var filterCheckboxes = $('.accordion input[type="checkbox"]');
    filterCheckboxes.change(function() { 
      if(this.value === "all"){
        if ($(this).is(':checked')) {
          $(this).closest('.filter-list').find('.styled-checkbox').prop("checked", true);
        }else{
          $(this).closest('.filter-list').find('.styled-checkbox').prop("checked", false);
        }        
      }else{
        $(this).closest('div').find(".listCheck input[type=checkbox]").each(function () {
          if (!$(this).is(':checked')) {
            $(this).closest('div').find(".check-all").prop("checked", false);
            return false;
          } else {
            $(this).closest('div').find(".check-all").prop("checked", true);
          }
        });
      }
        var search_values = [];
        selectedFilters = [];
        filterCheckboxes.filter(':checked').each(function(i_item, selected){        
        search_values.push(this.value);
        selectedFilters.push(this.id); 
        });

        //Check for mobile if any key search(grid view)
        var resultResponse = searchByValue(search_values, responseData);
        if ($('.content').hasClass('mobile-content-width')) {
          var searchText = $("#searchFunds").val();
          var searchResponse = [];
          if(searchText){
            searchResponse = resultResponse.filter(item => {
              return (item.ticker).toLowerCase().indexOf(searchText.toLowerCase()) > -1 || (item.fund.fundname).toLowerCase().indexOf(searchText.toLowerCase()) > -1
            })
          createList(searchResponse);
          }
        }
    });
};
    
function searchByValue(search_values, responseData) {
  filterdata = [];
  if (search_values && search_values.length > 0) {
    search_values.forEach((index) => {
      responseData.forEach((ele) => {
        const obj = ele.filter;
        Object.keys(obj).forEach((key) => {
          if (obj[key] == index) {
            if(filterdata.indexOf(ele) < 0){
              filterdata.push(ele);              
            }
          }
        });
      });
      redrawTable(filterdata);
      createList(filterdata);
    });
    return filterdata;
  } else {
    redrawTable(responseData);
    createList(responseData);
    return responseData;
  }
}

  function redrawTable(data) {
    fundstable.clear();
    fundstable.rows.add(data);
    fundstable.draw();
    $(".fundscount").html($(".dataTables_info").text()); 
  }

  $('.footer-button').click(function () {
    var panelHeight = window.innerHeight;
      $(".panel").css("height", panelHeight).slideToggle("slow");
      $(".close-filter, .open-filter").toggleClass("hidden");
      // $(".open-filter").toggleClass("hidden");
  });

  $('.angle--arrow').click(function() {
    $(".funds-list").toggleClass("active");
    $(".accordion").toggleClass("hidden");
    $(".angle--arrow").toggleClass("right--angle--arrow");
    $(".sidebar-collapse").toggleClass("filter-width");
    $(".content").toggleClass("pc-content-width");
    $($.fn.dataTable.tables( true ) ).css('width', '100%');
    $($.fn.dataTable.tables( true ) ).DataTable().columns.adjust().draw();
  });

  /* filter section close on mouse leave */

  // $('.sidebar-collapse.filter-width').on({
  //       mouseenter: function () {
  //           console.log("mouse enter");
  //             clearTimeout(timer);            
  //       },
  //       mouseleave: function () {
  //           console.log("mouse leave");
  //           timer = setTimeout(function(){ 
  //               $(".funds-list").removeClass("active");
  //               $(".accordion").addClass("hidden");
  //               $(".angle--arrow").removeClass("right--angle--arrow");
  //               $(".sidebar-collapse").removeClass("filter-width");
  //               $(".content").removeClass("pc-content-width");
  //           }, 3000);        
  //       }
  //   });

// filter radio buttons
$('#monthend').prop('checked', 'true');
// $('#monthend-mobile').prop('checked', 'true');
$('input[type="radio"]').change(function(){
  if(this.value=='quarterend'){
    $('.performance-monthly-data').addClass('hidden');
    $('.performance-quarterly-data').removeClass('hidden');
  }else{
    $('.performance-quarterly-data').addClass('hidden');
    $('.performance-monthly-data').removeClass('hidden');
  }
});
   
//to top of the page
 $('.to-top').click(function() {
  $("html, body").animate({scrollTop: 0});
  if($(".panel").length){
    $(".panel").animate({scrollTop: 0});
  }
 });

// create grid view for mobile
function createList(result) {

  $(".performance-content-grid-view, .rating-content-grid-view").html('');

  for (let i = 0; i < result.length; i++) {

    const data = result[i];

    var riskvalue = parseInt(data.risk);
    var riskfieldTemplate = '';
    for(var k = 1;k<= 7; k++){
      if(k <= riskvalue){
        riskfieldTemplate = riskfieldTemplate + ' <span class="risk-field active"></span>'
      }else{
        riskfieldTemplate = riskfieldTemplate + '<span class="risk-field"></span>'
      }
    }

    let performancetemplate = `<div class="performance-grid">
    <div class="header">
        <p class="ticker">${data.ticker}</p>
        <div class="fund-details">
            <a class="fund-name">${data.fund.fundname}</a>
            <p class="asset-class">${data.assetclass}</p>
        </div>            
    </div>
    <div class="fund-content">
        <div class="fund-content-row-one">
            <ul>
                <li>
                    <p class="fund-content-header">YTD</p>
                    <p class="fund-content-value">${data.ytd.ytdvalue}</p>
                </li>                    
                <li>
                    <p class="fund-content-header">1 Yr.</p>
                    <p class="fund-content-value performance-monthly-data">${data.performance.monthly.yearone.nav}</p>
                    <p class="fund-content-value performance-quarterly-data hidden">${data.performance.quarterly.yearone.load}</p>
                </li>
                <li>
                    <p class="fund-content-header">3 yr.</p>
                    <p class="fund-content-value performance-monthly-data">${data.performance.monthly.yearthree.nav}</p>
                    <p class="fund-content-value performance-quarterly-data hidden">${data.performance.quarterly.yearthree.load}</p>
                </li>
                <li>
                    <p class="fund-content-header">5 yr.</p>
                    <p class="fund-content-value performance-monthly-data">${data.performance.monthly.yearfive.nav}</p>
                    <p class="fund-content-value performance-quarterly-data hidden">${data.performance.quarterly.yearfive.load}</p>  
                </li>
                <li>
                    <p class="fund-content-header">10 yr.</p>
                    <p class="fund-content-value performance-monthly-data">${data.performance.monthly.yearten.nav}</p>
                    <p class="fund-content-value performance-quarterly-data hidden">${data.performance.quarterly.yearten.load}</p>  
                </li>
            </ul>
        </div>
        <div class="fund-content-row-two">
            <ul>
                <li>
                    <p class="fund-content-header">Since Inception (%)</p>
                    <p class="fund-content-value performance-monthly-data">${data.performance.monthly.since_inception.nav}</p>
                    <p class="fund-content-value performance-quarterly-data hidden">${data.performance.quarterly.since_inception.load}</p>  
                </li>
                <li>
                    <p class="fund-content-header">Incept Date</p>
                    <p class="fund-content-value">${data.inceptdate}</p>  
                </li>
                <li>
                    <p class="fund-content-header">Exp. Rat. (Gross)</p>
                    <p class="fund-content-value">${data.gross}</p>  
                </li>
                <li>
                    <p class="fund-content-header">Exp. Rat. (Net)</p>
                    <p class="fund-content-value">${data.net}</p>  
                </li>
            </ul>
        </div>
        <div class="fund-content-row-three">
            <ul>
                <li>
                    <p class="fund-content-header">Risk: <span class="fund-content-value"> Moderately Aggressive</span></p>
                </li>
                <li>
                    <p class="fund-content-header">${riskfieldTemplate}</p>
                </li>
            </ul>
        </div>
        </div>
    </div>`;

    $(".performance-content-grid-view").append(performancetemplate);

    var ratingvalue = parseInt(data.rating.overall.value);
    var stariconTemplate = '';
    for(var j = 1;j <= 5; j++){
      if(j <= ratingvalue){
        stariconTemplate = stariconTemplate + '<i class="fa fa-star active"></i>'
      }else{
        stariconTemplate = stariconTemplate + '<i class="fa fa-star"></i>'
      }
    }

    let ratingtemplate = `<div class="rating-grid">
    <div class="header">
        <p class="ticker">${data.ticker}</p>
        <div class="fund-details">
            <a class="fund-name">${data.fund.fundname}</a>
        </div>            
    </div>
    <div class="fund-content">
        <div class="rating-section">
            <div class="overall-rating">
                <p class="fund-content-header">Overall</p>
                <p class="star-rating">${stariconTemplate}</p>
                <p class="fund-content-value">Out of ${data.rating.overall.total} funds</p>  
            </div>
            <div class="years-rating">
                <p>
                    <span class="fund-content-header rating-years-header">3 yr:</span>
                    <span class="fund-content-header">${data.rating.yearthree.value}</span>
                    <span class="years-rating-star">
                      
                    </span>
                    <span class="fund-content-value">Out of ${data.rating.yearthree.total} funds</span>
                </p>
                <p>
                    <span class="fund-content-header rating-years-header">5 yr:</span>
                    <span class="fund-content-header">${data.rating.yearfive.value}</span>
                    <span class="years-rating-star"></span>
                    <span class="fund-content-value">Out of ${data.rating.yearfive.total} funds</span>
                </p>
                <p>
                    <span class="fund-content-header rating-years-header">10 yr:</span>
                    <span class="fund-content-header">${data.rating.yearten.value}</span>
                    <span class="years-rating-star"></span>
                    <span class="fund-content-value">Out of ${data.rating.yearten.total} funds</span>
                </p>
            </div>                  
        </div>
        <div class="pdf-section">
            <div class="rating-category">
                <p class="fund-content-header">Rating Category</p>
                <p class="fund-content-value">${data.rating.category}</p> 
            </div>
            <div class="fund-sheet">
                <a href="/">Fund Fact Sheet</a>                        
            </div>
        </div>
    </div>
</div>`;
$(".rating-content-grid-view").append(ratingtemplate);
  }

}


});



  var filterTemplate= `<div id="accordion" class="accordion">
  <div class="filter-header" data-toggle="collapse" data-parent="#accordion" data-target="#volatility">
      <p class="filter-title">Volatility </p>
  </div>
  <div id="volatility" class="filter-body collapse show" data-filtertype="volatility">
      <ul class="filter-list">
          <li class="filter-text">
              <input type="checkbox" id="check1" class="styled-checkbox check-all" value="all" />
              <label for="check1">All</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check2" class="styled-checkbox" value="preservationofcapital">
              <label for="check2">Preservation of Capital</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check3" class="styled-checkbox" value="conservative" />
              <label for="check3">Conservative</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check4" class="styled-checkbox" value="moderatelyconservative" />
              <label for="check4">Moderately Conservative</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check5" class="styled-checkbox" value="moderate" />
              <label for="check5">Moderate</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check6" class="styled-checkbox" value="aggressive" />
              <label for="check6">Aggressive</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check7" class="styled-checkbox" value="veryaggressive" />
              <label for="check7">Very Aggressive</label>
          </li>
      </ul>
      <p class="popup-modal">What is <span data-toggle="modal" data-target="#volatilityModal" class="popup-link">
        <a href="#">Volatility?</a></span>
      </p>
      <div class="modal" id="volatilityModal">
          <div class="modal-dialog">
              <div class="modal-content">

                  <!-- Modal Header -->
                  <div class="modal-header">
                      <!-- <button type="button" class="close" data-dismiss="modal">&times;</button>  -->
                      <a href="#" class="close" data-dismiss="modal">
                          <img src="./images/image-left.svg" alt="" class="image-left">
                          <img src="./images/image-right.svg" alt="" class="image-right">
                      </a>
                      <a href="#" data-dismiss="modal" class="close-link">Close</a>
                      <div class="modal-title">
                          <h4>What is volatility?</h4>
                          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                              tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At
                              vero
                              eos et accusam et justo duo dolores et ea rebum. Stet clita kasd
                              gubergren,<a href="#" class="learn-more-link">learn
                                  more</a></p>
                      </div>
                      <div class="heading-text">
                          <h4>Preservation of Capital</h4>
                          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                              tempor invidunt ut labore et dolore</p>
                          <h4>Conservative</h4>
                          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                              tempor invidunt ut labore et dolore</p>
                          <h4>Moderately Conservative</h4>
                          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                              tempor invidunt ut labore et dolore</p>
                          <h4>Moderate</h4>
                          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                              tempor invidunt ut labore et dolore</p>
                          <h4>Aggressive</h4>
                          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                              tempor invidunt ut labore et dolore</p>
                          <h4>Very Aggressive</h4>
                          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                              tempor invidunt ut labore et dolore</p>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <div class="filter-header " data-toggle="collapse" data-parent="#accordion" href="#fundtype">
      <p class="filter-title">Fund Type </p>
  </div>
  <div id="fundtype" class=" collapse show" data-filtertype="fundtype">
      <ul class="filter-list">
          <li class="filter-text">
              <input type="checkbox" id="check8" class="styled-checkbox check-all" value="all" />
              <label for="check8">All</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check9" class="styled-checkbox" value="starterfunds" />
              <label for="check9">Starter Funds</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check10" class="styled-checkbox" value="risk" />
              <label for="check10">Target Risk</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check11" class="styled-checkbox" value="retirement" />
              <label for="check11">Target Retirement</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check12" class="styled-checkbox" value="monymarket" />
              <label for="check12">Mony Market</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check13" class="styled-checkbox" value="taxablebond" />
              <label for="check13">Taxable Bond</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check14" class="styled-checkbox" value="stock" />
              <label for="check14">Stock</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check15" class="styled-checkbox" value="index" />
              <label for="check15">Index</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check16" class="styled-checkbox" value="sector" />
              <label for="check16">Alternative/Sector</label>
          </li>
      </ul>
  </div>
  <div class="filter-header" data-toggle="collapse" data-parent="#accordion" href="#minimuminvestment">
      <p class="filter-title">Minimum Investment </p>
  </div>
  <div id="minimuminvestment" class="collapse show" data-filtertype="minimuminvestment">
      <ul class="filter-list">
          <li class="filter-text">
              <input type="checkbox" id="check17" class="styled-checkbox check-all" value="all" />
              <label for="check17">All</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check18" class="styled-checkbox" value="monthly" />
              <label for="check18">$50 with $50 montthly</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check19" class="styled-checkbox" value="500" />
              <label for="check19">$500</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check20" class="styled-checkbox" value="1000" />
              <label for="check20">$1000</label>
          </li>
          <li class="filter-text listCheck">
              <input type="checkbox" id="check21" class="styled-checkbox" value="3000" />
              <label for="check21">$3000</label>
          </li>
      </ul>
  </div>

</div>`;


// load script function with callback to handle sync 
function loadScript(src) {
  script = document.createElement('script');
  script.src = src;
  document.getElementsByTagName('head')[0].appendChild(script);
}